import Starter from './DiceExercise.js';

export default Starter;
