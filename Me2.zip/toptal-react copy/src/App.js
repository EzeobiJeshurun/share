import React from 'react';
import './App.css';

import Application from './Starter.js';
import AnotherImplementation from './DiceExercise2';

function App() {
  return (
    <div className="App">
      <Application/>
      <AnotherImplementation/>
    </div>
  );
}

export default App;
