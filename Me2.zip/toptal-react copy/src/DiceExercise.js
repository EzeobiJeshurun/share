import React from "react";

const getDiceValues = (index) => {
  switch (index) {
    case 1:
      return [
        [0, 0, 0],
        [0, 1, 0],
        [0, 0, 0],
      ];
    case 2:
      return [
        [1, 0, 0],
        [0, 0, 0],
        [0, 0, 1],
      ];
    default:
      return [
        [1, 0, 1],
        [1, 0, 1],
        [1, 0, 1],
      ];
  }
};

const getNewIndex = () => 1 + Math.floor(Math.random() * 6);


export default function App() {
  const [data, setData] = React.useState(getNewIndex());

  return (
    <div className="container mx-auto m-8 flex">
      <div>
        <Dice data={getDiceValues(data)} />
      </div>
      <div className="ml-4">
        <div>
          <button
            className="text-center w-32 border"
            onClick={() => setData(getNewIndex())}
          >
            Throw dice
          </button>
        </div>
        <div>
          <p className="mt-2 text-center">Last throw: {data}</p>
        </div>
      </div>
    </div>
  );
}

const Dice = ({ data }) => {
  return (
    <table className="border border-black rounded-md p-48">
      <tbody>
        {data.map((show, i) => (
          <tr key={i}>
            {show.map((showData, x) =>
              showData === 0 ? <Nothing key={x} /> : <Eye key={x} />
            )}
          </tr>
        ))}
      </tbody>
    </table>
  );
};

const Eye = () => (
  <td className="w-12 h-12 p-2">
    <div className="bg-black w-12 h-12 rounded-full">&nbsp;</div>
  </td>
);
const Nothing = () => (
  <td className="w-12 h-12 p-2">
    <div className="bg-white w-12 h-12 rounded-full">&nbsp;</div>
  </td>
);
