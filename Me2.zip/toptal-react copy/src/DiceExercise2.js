import React, { useCallback, useRef, useEffect } from "react";

const getNewIndex = () => Math.floor(Math.random() * 6);
const images = [
  [0, 0, 0, 0, 1, 0, 0, 0, 0],
  [1, 0, 0, 0, 0, 0, 0, 0, 1],
  [1, 0, 0, 0, 1, 0, 0, 0, 1],
  [1, 0, 1, 0, 0, 0, 1, 0, 1],
  [1, 0, 1, 0, 1, 0, 1, 0, 1],
  [1, 0, 1, 1, 0, 1, 1, 0, 1],
];

const getSingleImage = (arr) => {
  return [arr.slice(0, 3), arr.slice(3, 6), arr.slice(6, 9)];
};

export default function App() {
  const shakeRef = useRef();
  const shakeTimeout = useRef();
  const [diceNumber, setDiceNumber] = React.useState(getNewIndex());
  const animateDice = useCallback(() => {
    clearInterval(shakeTimeout.current);
    shakeRef.current.animate(
      [
        // keyframes
        { transform: "rotate(20deg)" },
        { transform: "rotate(10deg)" },
        { transform: "rotate(-20deg)" },
        { transform: "rotate(-10deg)" },
      ],
      {
        // timing options
        duration: 1000,
        iterations: 4,
      }
    );

    //change dice pick
    shakeTimeout.current = setTimeout(() => {
      setDiceNumber(getNewIndex());
    }, [4150]);
  },[]);

  useEffect(() => {
    return () => {
      clearInterval(shakeTimeout.current);
    };
  }, []);

  return (
    <div className="container mx-auto m-8 flex">
      <h2>Here is Jeshuruns implementation: </h2>
      <div ref={shakeRef}>
        <Dice num={diceNumber} />
      </div>
      <div className="ml-4">
        <div>
          <button
            className="text-center w-32 border"
            onClick={() => animateDice()}
          >
            Throw dice
          </button>
        </div>
        <div>
          <p className="mt-2 text-center">Last throw: {diceNumber + 1}</p>
        </div>
      </div>
    </div>
  );
}

const Dice = ({ num }) => {
  return (
    <table className="border border-black rounded-md p-48">
      <tbody>
        {getSingleImage(images[num]).map((show, i) => (
          <tr key={i}>
            {show.map((showData, x) =>
              showData === 0 ? <Nothing key={x} /> : <Eye key={x} />
            )}
          </tr>
        ))}
      </tbody>
    </table>
  );
};

const Eye = () => (
  <td className="w-12 h-12 p-2">
    <div className="bg-black w-12 h-12 rounded-full">&nbsp;</div>
  </td>
);
const Nothing = () => (
  <td className="w-12 h-12 p-2">
    <div className="bg-white w-12 h-12 rounded-full">&nbsp;</div>
  </td>
);
